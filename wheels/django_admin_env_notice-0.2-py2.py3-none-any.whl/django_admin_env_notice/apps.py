# -*- coding: utf-8
from django.apps import AppConfig


class DjangoAdminEnvNoticeConfig(AppConfig):
    name = 'django_admin_env_notice'
